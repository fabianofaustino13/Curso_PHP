<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Tela de Login</title>
    </head>
    <body>
        <form action="valida.php" method="post">
            <label for="login">Login:</label>
            <input type="text" id="login" name="login">
            <br><br>
            <label for="senha">Senha:</label>
            <input type="password" id="senha" name="senha">
            <br><br>
            <button type="submit">Enviar</button>
        </form>
    </body>
</html>
