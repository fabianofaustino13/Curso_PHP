<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Adicionar Categoria</title>
    </head>
    <body>
        <form action="insere-categoria.php" method="post">
            <label for="nome">Categoria</label>
            <input type="text" id="nome" name="nome">
            <button type="submit">Cadastrar</button>
        </form>
    </body>
</html>
