<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Página 1</title>
    </head>
    <body>
        <form action="passo2.php" method="post">
            <label for="nome">Nome:</label>
            <input type="text" id="nome" name="nome">
            <button type="submit">Enviar</button>
        </form>
    </body>
</html>
